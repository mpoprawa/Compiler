Autor: Mikołaj Poprawa
Numer indeksu: 272370

Kompilacja:
make all

Uruchomienie:
python3 compiler.py <nazwa pliku wejściowego> <nazwa pliku wyjściowego>

Użyte narzędzia:
-flex
-bison

Pliki:
-parser.y - główny parser
-lexer.l - główny lexer
-label_parser.y - parser etykiet
-label_lexer.l - lexer etykiet
-compiler.py - program wywołujący elementy kompilatora